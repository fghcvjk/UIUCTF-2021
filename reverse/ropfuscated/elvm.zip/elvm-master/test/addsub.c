int putchar(int x);

int main() {
  putchar('5' + 3);
  putchar('5' - 3);
  return 0;
}
