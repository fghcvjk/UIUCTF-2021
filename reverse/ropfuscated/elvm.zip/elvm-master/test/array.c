#include <stdio.h>

int main() {
  int arr[16];
  arr[0] = 42;
  arr[1] = 43;
  arr[2] = 44;
  putchar(arr[0]);
  putchar(arr[1]);
  putchar(arr[2]);
  return 0;
}
