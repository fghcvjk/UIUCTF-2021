#include "../libc/_raw_print.h"

int main() {
  print_int(7);
  print_int(42);
  print_int(123);
  print_int(0);
  //print_int(-99);
  return 0;
}
