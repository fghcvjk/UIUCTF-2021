int putchar(int x);

int main() {
  putchar('X');
  return 0;
}
