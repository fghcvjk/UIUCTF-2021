puts 'add B, 65535'
500.times{
  puts 'mov A, B'
}
puts "exit"
