int getchar();
int putchar(int x);

int main() {
  int c = getchar();
  putchar(c);
  return 0;
}
