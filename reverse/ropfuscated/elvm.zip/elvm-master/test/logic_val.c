#include "../libc/_raw_print.h"

int main() {
  print_int(2 && 2);
}
