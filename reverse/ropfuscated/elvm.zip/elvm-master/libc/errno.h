#ifndef ELVM_LIBC_ERRNO_H_
#define ELVM_LIBC_ERRNO_H_

int errno;

#endif  // ELVM_LIBC_ERRNO_H_
