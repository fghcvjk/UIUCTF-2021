#ifndef ELVM_LIBC_MATH_H_
#define ELVM_LIBC_MATH_H_

#endif  // ELVM_LIBC_MATH_H_
