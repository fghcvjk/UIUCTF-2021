#ifndef ELVM_LIBC_INTTYPES_H_
#define ELVM_LIBC_INTTYPES_H_

#include <stdint.h>

#define PRIu64 "l"

#endif  // ELVM_LIBC_INTTYPES_H_
