#ifndef ELVM_LIBC_TIME_H_
#define ELVM_LIBC_TIME_H_

typedef int time_t;

#endif  // ELVM_LIBC_TIME_H_
