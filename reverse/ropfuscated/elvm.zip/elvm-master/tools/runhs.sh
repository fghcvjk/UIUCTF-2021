#!/bin/sh

set -e

runghc $1 -o a.out
