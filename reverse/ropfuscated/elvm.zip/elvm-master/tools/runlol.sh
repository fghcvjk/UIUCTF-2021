#!/bin/sh

set -e

cd lci
lci $1
cd ..